package com.eltavine.duckdetector.features.playintegrityfix.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.eltavine.duckdetector.features.playintegrityfix.data.repository.PlayIntegrityFixRepository
import com.eltavine.duckdetector.features.playintegrityfix.domain.PlayIntegrityFixReport
import com.eltavine.duckdetector.features.playintegrityfix.domain.PlayIntegrityFixStage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PlayIntegrityFixViewModel(
    private val repository: PlayIntegrityFixRepository,
    private val mapper: PlayIntegrityFixCardModelMapper = PlayIntegrityFixCardModelMapper(),
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        PlayIntegrityFixUiState(
            stage = PlayIntegrityFixUiStage.LOADING,
            report = PlayIntegrityFixReport.loading(),
            cardModel = mapper.map(PlayIntegrityFixReport.loading()),
        ),
    )
    val uiState: StateFlow<PlayIntegrityFixUiState> = _uiState.asStateFlow()

    init {
        rescan()
    }

    fun rescan() {
        viewModelScope.launch {
            val loading = PlayIntegrityFixReport.loading()
            _uiState.update {
                it.copy(
                    stage = PlayIntegrityFixUiStage.LOADING,
                    report = loading,
                    cardModel = mapper.map(loading),
                )
            }

            val report = repository.scan()
            _uiState.update {
                it.copy(
                    stage = if (report.stage == PlayIntegrityFixStage.FAILED) {
                        PlayIntegrityFixUiStage.FAILED
                    } else {
                        PlayIntegrityFixUiStage.READY
                    },
                    report = report,
                    cardModel = mapper.map(report),
                )
            }
        }
    }

    companion object {
        fun factory(): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return PlayIntegrityFixViewModel(PlayIntegrityFixRepository()) as T
                }
            }
        }
    }
}
