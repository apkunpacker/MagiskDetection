#pragma once

#include "zygisk/common/types.h"

namespace duckdetector::zygisk {

    ProbeResult collect_atexit_probe();

}  // namespace duckdetector::zygisk
